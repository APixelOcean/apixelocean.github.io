import{a as t}from"../chunks/entry.B2_hIZoj.js";export{t as start};
