import{a as t}from"../chunks/entry.CV9JmNra.js";export{t as start};
